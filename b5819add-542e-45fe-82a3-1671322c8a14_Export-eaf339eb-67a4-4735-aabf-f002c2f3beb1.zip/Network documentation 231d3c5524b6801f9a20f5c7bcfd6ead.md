# Network documentation

The objective of this project was to design and implement a corporate network (CorpNet) across three sites, utilizing multiple VLANs and diverse technologies

![image.png](image.png)

### **Site A**

[[**Site A**](Network%20documentation%20231d3c5524b6801f9a20f5c7bcfd6ead.md)](Site%20A%20231d3c5524b6801da672d443891ac69f.md)

Site A is the company’s main site and has four VLANs, each directly connected to an access switch. In our topology, we have:

- VLAN10 Management
- VLAN20 HR
- VLAN30 IT
- VLAN40 Sales

Each access switch is connected to CoreSWA, which serves as the core and central device of the main site. CoreSWA is connected to RouterA, which acts as the default gateway for all end hosts. RouterA is also connected to the Internet Service Provider (ISP).

![image.png](image%201.png)

### **Site B**

[**Site B**](Site%20B%20231d3c5524b680d3a828c9ceaec3e849.md)

Site B is the company’s branch site and consists of three VLANs, each connected to access switches as well. In this topology, we have:

- VLAN110 Production
- VLAN120 Support
- VLAN130 Development

Each switch is connected to an access router. Both access routers are directly connected to each other, as well as to RouterB, which serves as the default gateway for all end hosts. Additionally, RouterB is connected to the ISP.

![image.png](image%202.png)

### **DC Site**

[**DC Site**](DC%20Site%20231d3c5524b6808b88d7cad29776eafd.md)

The DC site is the third and final site in our topology. This site is responsible for providing IP services such as DHCP, DNS, FTP, and others via servers. Additionally, RouterC acts as the default gateway for the server and provides a direct connection to the ISP.

![image.png](image%203.png)